```ini
title = Web Server
slug = docs/deploy-static
date = 2015-11-28
update_date = 2015-12-30
author = fuxiaohei
author_email = fuxiaohei@vip.qq.com
hover = docs
template =

[meta]
Source = "https://github.com/go-xiaohei/pugo/blob/master/doc/source/page/deploy/static.md"
Version = "0.9.0"
```

After run `build` command, you can get some compiled html files to serve in your `--dest` directory. Then use a web server to serve them.

#### Nginx

// todo

#### Apache

// todo

#### Candy

// todo